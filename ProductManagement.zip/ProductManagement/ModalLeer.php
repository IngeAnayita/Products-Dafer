<div class="modal fade" id="ModalLeer" tabindex="-1" role="dialog" aria-labelledby="ModalLeerLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
            <form id="buscarProductoForm">
            <div class="form-group">
            <label for="nombre_producto">Nombre del Producto:</label>
            <input type="text" class="form-control" id="nombre_producto" name="nombre_producto" required>
            </div>
            <button type="submit" class="btn btn-primary">Buscar</button>
            </form>
            <div id="resultadosBusqueda" class="mt-5"></div>
            </div>
        </div>
    </div>
</div>
